-- MySQL dump 10.13  Distrib 5.1.61, for redhat-linux-gnu (x86_64)
--
-- Host: localhost    Database: u683362690_rtblz
-- ------------------------------------------------------
-- Server version	5.1.61
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accounts`
--

DROP TABLE IF EXISTS `accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accounts` (
  `username` varchar(16) NOT NULL,
  `password` varchar(32) NOT NULL,
  `salt` varchar(16) NOT NULL,
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `joined` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_login` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `email` varchar(32) NOT NULL,
  `pending_email` varchar(32) NOT NULL,
  `posts` int(11) unsigned NOT NULL DEFAULT '0',
  `comments` int(11) unsigned NOT NULL DEFAULT '0',
  `moderated` int(11) unsigned NOT NULL DEFAULT '0',
  `country_id` int(5) NOT NULL DEFAULT '-1',
  `description` varchar(130) NOT NULL,
  `hidelocation` tinyint(1) NOT NULL DEFAULT '0',
  `hiderelated` tinyint(1) NOT NULL DEFAULT '0',
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `mod_index` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `id_5` (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `id` (`id`),
  KEY `id_2` (`id`),
  KEY `id_3` (`id`),
  KEY `id_4` (`id`),
  KEY `id_6` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts`
--

LOCK TABLES `accounts` WRITE;
/*!40000 ALTER TABLE `accounts` DISABLE KEYS */;
INSERT INTO `accounts` VALUES ('PenisPulley','112670935a8b1a01c30dc55985fff4d5','P×_Xä’Úb/tÔ\"ô',4,'2014-05-06 21:13:49','2014-05-23 12:13:19','fcktb4703@gmail.com','',0,0,0,-1,'',0,0,0,0),('valobster','2838b2752b09799b53658edb5bee1939','7$žzlIì@ZÅÐf\r7øÅ',5,'2014-05-11 06:36:21','2014-05-20 05:49:42','shelbyhouse727@gmail.com','',0,0,0,-1,'',0,0,0,0),('Adam','3ef5e37d06172b4871766d42ca3e719e','<+\\Î^\"çö©æ‚Á}`¿',7,'2014-05-29 22:00:46','2014-10-04 17:03:43','adamlupka17@gmail.com','',0,0,0,40,'I am the founder of Relatablez.',0,0,1,4),('Insomniac10102','670e7657d16133872f87163576168751','êÔÝîZGørÁWÑ(G\0Éê',10,'2014-01-21 10:21:44','2014-10-07 07:28:28','tyhckt@yahoo.com','ins10102@gmail.com',0,0,0,236,'I am the lead developer of Relatablez. Welcome to my profile.',0,0,1,6),('Relatablez Staff','','',0,'2014-01-19 05:00:00','2014-08-08 03:37:40','Contact@Relatablez.com','',0,0,0,-1,'',0,0,0,0);
/*!40000 ALTER TABLE `accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_articles`
--

DROP TABLE IF EXISTS `blog_articles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_articles` (
  `id` smallint(16) unsigned NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) unsigned NOT NULL,
  `title` varchar(60) COLLATE latin1_general_ci NOT NULL,
  `content` text COLLATE latin1_general_ci NOT NULL,
  `image` varchar(120) COLLATE latin1_general_ci NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_articles`
--

LOCK TABLES `blog_articles` WRITE;
/*!40000 ALTER TABLE `blog_articles` DISABLE KEYS */;
INSERT INTO `blog_articles` VALUES (1,10,'Welcome to the New Relatablez Blog!','<b>Hello, World!</b><br>\r\n<br>\r\nThis is an example article for the latest addition to our relatable content - blogs!','/images/2014/9/26/desert.jpg','2014-09-26 12:06:57'),(2,7,'This is a Test Article','Welcome to Relatablez!<br>\r\n<br>\r\nBlah Blah Blah..','/images/2014/9/26/Internet-IPv6.jpg','2014-09-26 13:20:46'),(3,7,'Test','dsdsds<br>\r\n<br>\r\nsd<br>\r\ns<br>\r\nds<br>\r\nds<br>\r\n<br>\r\nds<br>\r\nds<br>\r\n','/images/2014/9/26/Internet-IPv6.jpg','2014-09-26 13:22:40'),(4,7,'Test for image placement','I deleted ur amazing horse by accident. plz forgive','','2014-09-26 13:31:51');
/*!40000 ALTER TABLE `blog_articles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment_ratings`
--

DROP TABLE IF EXISTS `comment_ratings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comment_ratings` (
  `cid` bigint(20) unsigned NOT NULL,
  `uid` bigint(20) unsigned NOT NULL,
  `vote` tinyint(1) NOT NULL,
  UNIQUE KEY `cr_index` (`cid`,`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment_ratings`
--

LOCK TABLES `comment_ratings` WRITE;
/*!40000 ALTER TABLE `comment_ratings` DISABLE KEYS */;
INSERT INTO `comment_ratings` VALUES (1,10,1),(9,10,1),(10,10,-1);
/*!40000 ALTER TABLE `comment_ratings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comments` (
  `pid` bigint(20) unsigned NOT NULL,
  `cid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment` varchar(180) COLLATE latin1_general_ci NOT NULL,
  `uid` bigint(20) unsigned NOT NULL,
  `submitted` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `rid` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`cid`),
  UNIQUE KEY `comment_id` (`cid`)
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
INSERT INTO `comments` VALUES (0,1,'hey folks',10,'2014-09-30 08:37:40',0),(0,2,'test comment',0,'2014-10-01 09:08:33',0),(0,3,'test comment reply to insomniac',4,'2014-10-01 09:09:21',1),(0,4,'Latest reply to Insomniac.',7,'2014-10-01 09:29:01',1),(0,5,'Reply to Relatablez',10,'2014-10-01 09:54:40',2),(0,6,'Hello World.',10,'2014-10-02 03:27:55',0),(1,7,'first comment on this post!',10,'2014-10-02 04:10:58',0),(0,8,'Test Reply to P-Guy',0,'2014-10-02 08:37:58',1),(0,9,'Test',7,'2014-10-02 23:36:36',0),(0,10,'@Adam Hello',10,'2014-10-03 00:06:08',9),(0,11,'@Insomniac10102 Hello',10,'2014-10-03 00:06:22',9),(0,12,'@Insomniac10102 Test',7,'2014-10-03 00:23:30',9),(0,13,'@Insomniac10102 Test',7,'2014-10-03 00:23:31',9),(0,14,'@Insomniac10102 Test',7,'2014-10-03 00:23:31',9),(0,15,'@Adam Testing',7,'2014-10-03 00:43:46',9),(0,16,'@Adam Testing',7,'2014-10-03 00:43:47',9),(0,17,'@Adam Herro',7,'2014-10-03 00:44:20',9),(0,18,'@Adam Herro',7,'2014-10-03 00:44:21',9),(0,19,'@Adam lol',7,'2014-10-03 00:45:09',9),(0,20,'@Adam sds',7,'2014-10-03 00:45:21',9),(0,21,'@Adam sds',7,'2014-10-03 00:45:23',9),(0,22,'@Adam sdsds',7,'2014-10-03 00:45:30',9),(0,23,'@Adam Dis is a reply',7,'2014-10-03 20:57:45',9),(0,24,'@Adam Dis is a reply',7,'2014-10-03 20:57:45',9),(0,25,'@Adam Dis is a reply',7,'2014-10-03 20:57:46',9),(0,26,'@Insomniac10102 Ohai',10,'2014-10-04 08:16:57',9),(0,27,'@Insomniac10102 Test',10,'2014-10-04 08:27:32',9),(0,28,'@Adam Check it out, you got mail.',10,'2014-10-04 08:31:03',9),(0,29,'@Adam Test',7,'2014-10-04 17:03:59',9),(0,30,'@Adam Test',7,'2014-10-04 17:04:01',9);
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `countries`
--

DROP TABLE IF EXISTS `countries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `countries` (
  `country_id` int(5) NOT NULL AUTO_INCREMENT,
  `iso2` char(2) DEFAULT NULL,
  `short_name` varchar(80) NOT NULL DEFAULT '',
  PRIMARY KEY (`country_id`)
) ENGINE=MyISAM AUTO_INCREMENT=251 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `countries`
--

LOCK TABLES `countries` WRITE;
/*!40000 ALTER TABLE `countries` DISABLE KEYS */;
INSERT INTO `countries` VALUES (1,'AF','Afghanistan'),(2,'AX','Aland Islands'),(3,'AL','Albania'),(4,'DZ','Algeria'),(5,'AS','American Samoa'),(6,'AD','Andorra'),(7,'AO','Angola'),(8,'AI','Anguilla'),(9,'AQ','Antarctica'),(10,'AG','Antigua and Barbuda'),(11,'AR','Argentina'),(12,'AM','Armenia'),(13,'AW','Aruba'),(14,'AU','Australia'),(15,'AT','Austria'),(16,'AZ','Azerbaijan'),(17,'BS','Bahamas'),(18,'BH','Bahrain'),(19,'BD','Bangladesh'),(20,'BB','Barbados'),(21,'BY','Belarus'),(22,'BE','Belgium'),(23,'BZ','Belize'),(24,'BJ','Benin'),(25,'BM','Bermuda'),(26,'BT','Bhutan'),(27,'BO','Bolivia'),(28,'BQ','Bonaire, Sint Eustatius and Saba'),(29,'BA','Bosnia and Herzegovina'),(30,'BW','Botswana'),(31,'BV','Bouvet Island'),(32,'BR','Brazil'),(33,'IO','British Indian Ocean Territory'),(34,'BN','Brunei'),(35,'BG','Bulgaria'),(36,'BF','Burkina Faso'),(37,'BI','Burundi'),(38,'KH','Cambodia'),(39,'CM','Cameroon'),(40,'CA','Canada'),(41,'CV','Cape Verde'),(42,'KY','Cayman Islands'),(43,'CF','Central African Republic'),(44,'TD','Chad'),(45,'CL','Chile'),(46,'CN','China'),(47,'CX','Christmas Island'),(48,'CC','Cocos (Keeling) Islands'),(49,'CO','Colombia'),(50,'KM','Comoros'),(51,'CG','Congo'),(52,'CK','Cook Islands'),(53,'CR','Costa Rica'),(54,'CI','Cote d\'ivoire (Ivory Coast)'),(55,'HR','Croatia'),(56,'CU','Cuba'),(57,'CW','Curacao'),(58,'CY','Cyprus'),(59,'CZ','Czech Republic'),(60,'CD','Democratic Republic of the Congo'),(61,'DK','Denmark'),(62,'DJ','Djibouti'),(63,'DM','Dominica'),(64,'DO','Dominican Republic'),(65,'EC','Ecuador'),(66,'EG','Egypt'),(67,'SV','El Salvador'),(68,'GQ','Equatorial Guinea'),(69,'ER','Eritrea'),(70,'EE','Estonia'),(71,'ET','Ethiopia'),(72,'FK','Falkland Islands (Malvinas)'),(73,'FO','Faroe Islands'),(74,'FJ','Fiji'),(75,'FI','Finland'),(76,'FR','France'),(77,'GF','French Guiana'),(78,'PF','French Polynesia'),(79,'TF','French Southern Territories'),(80,'GA','Gabon'),(81,'GM','Gambia'),(82,'GE','Georgia'),(83,'DE','Germany'),(84,'GH','Ghana'),(85,'GI','Gibraltar'),(86,'GR','Greece'),(87,'GL','Greenland'),(88,'GD','Grenada'),(89,'GP','Guadaloupe'),(90,'GU','Guam'),(91,'GT','Guatemala'),(92,'GG','Guernsey'),(93,'GN','Guinea'),(94,'GW','Guinea-Bissau'),(95,'GY','Guyana'),(96,'HT','Haiti'),(97,'HM','Heard Island and McDonald Islands'),(98,'HN','Honduras'),(99,'HK','Hong Kong'),(100,'HU','Hungary'),(101,'IS','Iceland'),(102,'IN','India'),(103,'ID','Indonesia'),(104,'IR','Iran'),(105,'IQ','Iraq'),(106,'IE','Ireland'),(107,'IM','Isle of Man'),(108,'IL','Israel'),(109,'IT','Italy'),(110,'JM','Jamaica'),(111,'JP','Japan'),(112,'JE','Jersey'),(113,'JO','Jordan'),(114,'KZ','Kazakhstan'),(115,'KE','Kenya'),(116,'KI','Kiribati'),(117,'XK','Kosovo'),(118,'KW','Kuwait'),(119,'KG','Kyrgyzstan'),(120,'LA','Laos'),(121,'LV','Latvia'),(122,'LB','Lebanon'),(123,'LS','Lesotho'),(124,'LR','Liberia'),(125,'LY','Libya'),(126,'LI','Liechtenstein'),(127,'LT','Lithuania'),(128,'LU','Luxembourg'),(129,'MO','Macao'),(130,'MK','Macedonia'),(131,'MG','Madagascar'),(132,'MW','Malawi'),(133,'MY','Malaysia'),(134,'MV','Maldives'),(135,'ML','Mali'),(136,'MT','Malta'),(137,'MH','Marshall Islands'),(138,'MQ','Martinique'),(139,'MR','Mauritania'),(140,'MU','Mauritius'),(141,'YT','Mayotte'),(142,'MX','Mexico'),(143,'FM','Micronesia'),(144,'MD','Moldava'),(145,'MC','Monaco'),(146,'MN','Mongolia'),(147,'ME','Montenegro'),(148,'MS','Montserrat'),(149,'MA','Morocco'),(150,'MZ','Mozambique'),(151,'MM','Myanmar (Burma)'),(152,'NA','Namibia'),(153,'NR','Nauru'),(154,'NP','Nepal'),(155,'NL','Netherlands'),(156,'NC','New Caledonia'),(157,'NZ','New Zealand'),(158,'NI','Nicaragua'),(159,'NE','Niger'),(160,'NG','Nigeria'),(161,'NU','Niue'),(162,'NF','Norfolk Island'),(163,'KP','North Korea'),(164,'MP','Northern Mariana Islands'),(165,'NO','Norway'),(166,'OM','Oman'),(167,'PK','Pakistan'),(168,'PW','Palau'),(169,'PS','Palestine'),(170,'PA','Panama'),(171,'PG','Papua New Guinea'),(172,'PY','Paraguay'),(173,'PE','Peru'),(174,'PH','Phillipines'),(175,'PN','Pitcairn'),(176,'PL','Poland'),(177,'PT','Portugal'),(178,'PR','Puerto Rico'),(179,'QA','Qatar'),(180,'RE','Reunion'),(181,'RO','Romania'),(182,'RU','Russia'),(183,'RW','Rwanda'),(184,'BL','Saint Barthelemy'),(185,'SH','Saint Helena'),(186,'KN','Saint Kitts and Nevis'),(187,'LC','Saint Lucia'),(188,'MF','Saint Martin'),(189,'PM','Saint Pierre and Miquelon'),(190,'VC','Saint Vincent and the Grenadines'),(191,'WS','Samoa'),(192,'SM','San Marino'),(193,'ST','Sao Tome and Principe'),(194,'SA','Saudi Arabia'),(195,'SN','Senegal'),(196,'RS','Serbia'),(197,'SC','Seychelles'),(198,'SL','Sierra Leone'),(199,'SG','Singapore'),(200,'SX','Sint Maarten'),(201,'SK','Slovakia'),(202,'SI','Slovenia'),(203,'SB','Solomon Islands'),(204,'SO','Somalia'),(205,'ZA','South Africa'),(206,'GS','South Georgia and the South Sandwich Islands'),(207,'KR','South Korea'),(208,'SS','South Sudan'),(209,'ES','Spain'),(210,'LK','Sri Lanka'),(211,'SD','Sudan'),(212,'SR','Suriname'),(213,'SJ','Svalbard and Jan Mayen'),(214,'SZ','Swaziland'),(215,'SE','Sweden'),(216,'CH','Switzerland'),(217,'SY','Syria'),(218,'TW','Taiwan'),(219,'TJ','Tajikistan'),(220,'TZ','Tanzania'),(221,'TH','Thailand'),(222,'TL','Timor-Leste (East Timor)'),(223,'TG','Togo'),(224,'TK','Tokelau'),(225,'TO','Tonga'),(226,'TT','Trinidad and Tobago'),(227,'TN','Tunisia'),(228,'TR','Turkey'),(229,'TM','Turkmenistan'),(230,'TC','Turks and Caicos Islands'),(231,'TV','Tuvalu'),(232,'UG','Uganda'),(233,'UA','Ukraine'),(234,'AE','United Arab Emirates'),(235,'GB','United Kingdom'),(236,'US','United States'),(237,'UM','United States Minor Outlying Islands'),(238,'UY','Uruguay'),(239,'UZ','Uzbekistan'),(240,'VU','Vanuatu'),(241,'VA','Vatican City'),(242,'VE','Venezuela'),(243,'VN','Vietnam'),(244,'VG','Virgin Islands, British'),(245,'VI','Virgin Islands, US'),(246,'WF','Wallis and Futuna'),(247,'EH','Western Sahara'),(248,'YE','Yemen'),(249,'ZM','Zambia'),(250,'ZW','Zimbabwe');
/*!40000 ALTER TABLE `countries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `sid` bigint(20) unsigned NOT NULL,
  `uid` bigint(20) unsigned NOT NULL,
  `subject` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `message` varchar(140) COLLATE latin1_general_ci NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `seen` tinyint(1) NOT NULL DEFAULT '0',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `nid` (`id`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES (1,10,10,'Notification Subject','This is a test message that is marked as \'read\'. Notice the gray circle :D','2014-07-25 03:00:07',1,1),(2,0,10,'Surprise!','Beep. You and I can sign into this account with no password.','2014-07-25 08:09:50',1,1),(3,0,10,'beep boop','Third message; scroll to your heart\'s content <3.','2014-07-25 11:31:24',1,1),(4,0,10,'New Message','New test message for finding a good spot to put a \"delete\" button. There\'s gotta be a good place somewhere...','2014-07-26 04:16:14',1,1),(5,0,10,'Reply from ','You have received a reply from  on <a href=\'http://www.relatablez.com/post/\'>this post</a>.','2014-10-04 08:25:15',1,0),(6,0,10,'Reply from Insomniac','You have received a reply from Insomniac10102 on <a href=\'http://www.relatablez.com/post/0\'>this post</a>.','2014-10-04 08:27:32',1,0),(7,0,7,'Reply from Insomniac','You have received a reply from Insomniac10102 on <a href=\'http://www.relatablez.com/post/0\'>this post</a>.','2014-10-04 08:31:03',1,0),(8,0,7,'Reply from Adam','You have received a reply from Adam on <a href=\'http://www.relatablez.com/post/0\'>this post</a>.','2014-10-04 17:03:59',1,0),(9,0,7,'Reply from Adam','You have received a reply from Adam on <a href=\'http://www.relatablez.com/post/0\'>this post</a>.','2014-10-04 17:04:01',1,0);
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `qotw`
--

DROP TABLE IF EXISTS `qotw`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qotw` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `question` varchar(300) COLLATE latin1_general_ci NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `qotw`
--

LOCK TABLES `qotw` WRITE;
/*!40000 ALTER TABLE `qotw` DISABLE KEYS */;
INSERT INTO `qotw` VALUES (1,'Are you afraid of the dark?','2014-09-16 10:03:37');
/*!40000 ALTER TABLE `qotw` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `qotw_options`
--

DROP TABLE IF EXISTS `qotw_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qotw_options` (
  `qid` mediumint(8) unsigned NOT NULL,
  `id` tinyint(1) NOT NULL COMMENT 'ID is in relation to the qotw this belongs to.',
  `answer` varchar(30) COLLATE latin1_general_ci NOT NULL,
  UNIQUE KEY `unique_index` (`qid`,`answer`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `qotw_options`
--

LOCK TABLES `qotw_options` WRITE;
/*!40000 ALTER TABLE `qotw_options` DISABLE KEYS */;
INSERT INTO `qotw_options` VALUES (1,0,'Yes'),(1,1,'No');
/*!40000 ALTER TABLE `qotw_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `qotw_votes`
--

DROP TABLE IF EXISTS `qotw_votes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qotw_votes` (
  `uid` bigint(20) unsigned NOT NULL,
  `v` tinyint(1) NOT NULL,
  `qid` mediumint(8) unsigned NOT NULL,
  UNIQUE KEY `qotw_votes_key` (`qid`,`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `qotw_votes`
--

LOCK TABLES `qotw_votes` WRITE;
/*!40000 ALTER TABLE `qotw_votes` DISABLE KEYS */;
INSERT INTO `qotw_votes` VALUES (1,1,1),(2,0,1);
/*!40000 ALTER TABLE `qotw_votes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `related`
--

DROP TABLE IF EXISTS `related`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `related` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `pid` bigint(20) unsigned NOT NULL,
  `uid` bigint(20) unsigned NOT NULL,
  `alone` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `related_key` (`pid`,`uid`),
  KEY `pid` (`pid`,`uid`),
  KEY `pid_2` (`pid`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `related`
--

LOCK TABLES `related` WRITE;
/*!40000 ALTER TABLE `related` DISABLE KEYS */;
INSERT INTO `related` VALUES (1,0,1,1),(2,0,3,0),(3,0,0,0),(4,1,10,0),(5,0,10,0),(6,0,7,0),(7,1,7,1);
/*!40000 ALTER TABLE `related` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `submissions`
--

DROP TABLE IF EXISTS `submissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `submissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` bigint(10) unsigned NOT NULL,
  `verification` int(11) NOT NULL,
  `category` varchar(16) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `alone` int(11) unsigned NOT NULL DEFAULT '0',
  `notalone` int(11) unsigned NOT NULL DEFAULT '0',
  `pending` tinyint(1) NOT NULL DEFAULT '1',
  `submission` text NOT NULL,
  `anonymous` tinyint(1) NOT NULL DEFAULT '0',
  `nsfw` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_2` (`id`),
  KEY `id` (`id`),
  KEY `id_3` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `submissions`
--

LOCK TABLES `submissions` WRITE;
/*!40000 ALTER TABLE `submissions` DISABLE KEYS */;
INSERT INTO `submissions` VALUES (0,10,0,'1','2014-01-21 05:00:00',1305,24127,0,'Am I the only one that thinks this website needs work??',0,0),(1,10,0,'1','2014-07-16 07:14:26',12,26,0,'Am I the only one testing submission functionality?',0,0),(2,10,0,'2','2014-07-23 21:04:45',2,7,1,'Am I the only one making multiple questions for the sake of science?',0,0),(3,10,0,'2','2014-07-23 22:01:43',1,4,1,'Am I the only one that needs a third pending post?',0,0),(4,10,0,'2','2014-07-23 22:04:30',1,4,1,'Am I the only one who uses \"who\" after \"Am I the only one\"?',0,0),(5,10,0,'1','2014-07-24 08:25:33',0,4,1,'Am I the only one who needs another submission for moderating?',0,0),(6,7,0,'1','2014-08-30 23:06:11',0,1,1,'Am I the only one who wants this to work already?',0,0);
/*!40000 ALTER TABLE `submissions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-10-07  4:09:37
